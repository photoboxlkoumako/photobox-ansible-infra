package Ocsinventory::Agent::Backend::OS::Generic;

use strict;


sub run {}

1;
