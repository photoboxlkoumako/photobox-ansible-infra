package Ocsinventory::Agent::Backend::OS::Generic::Lsusb;
use strict;

sub check {can_run("lsusb")}


sub run {}
1;
