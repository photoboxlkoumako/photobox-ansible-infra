package Ocsinventory::Agent::Backend::OS::Generic::Lspci;
use strict;

sub check {can_run("lspci")}


sub run {}
1;
